from routes.celular import app

app.run()
